import 'package:flutter/material.dart';

class LabelViewModel {
  final String text;

  LabelViewModel({
    required this.text,
  });
}