import 'package:flutter/material.dart';

class UserIconModel {
  final Image image;

  UserIconModel({
    required this.image,
  });
}