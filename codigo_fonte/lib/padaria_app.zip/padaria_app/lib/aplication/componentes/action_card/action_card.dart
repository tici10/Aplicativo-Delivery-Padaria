import 'package:flutter/material.dart';
import 'package:padaria_app/aplication/componentes/action_button/view_model_button.dart';
import 'package:padaria_app/aplication/componentes/action_card/view_model_card.dart';
import 'package:padaria_app/aplication/resources/shared/styles.dart';
import 'package:padaria_app/aplication/resources/shared/colors.dart';
import 'package:padaria_app/aplication/componentes/action_button/action_button.dart';
import 'package:padaria_app/aplication/scenes/produtos/produto_screen.dart';

class ActionCard extends StatelessWidget {
  final CardViewModel viewModel;
  final ActionButton view_model_button;
  TextStyle styleproduto1;
  TextStyle styleproduto2;
  double size;

  ActionCard._({
    super.key,
    required this.viewModel,
    required this.view_model_button,
    this.styleproduto1= nomeproduto,
    this.styleproduto2 = precoproduto,
    this.size = 120,
  });
  

  static ActionCard instantiate({required CardViewModel viewModel, required ActionButton view_model_button, styleproduto1 = nomeproduto, styleproduto2 = precoproduto, size= 120}){
    return ActionCard._(viewModel: viewModel, view_model_button: view_model_button,);
  }

 
  Widget createCard(BuildContext context){
    return Card(
      margin: EdgeInsets.all(10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          SizedBox(
            height: 100.0,
            width: 190.0,
            child: Image.asset(viewModel.image),
          ),
          Text(
            viewModel.nome,
            style: nomeproduto,
          ),
          Text(
            viewModel.preco,
            style: precoproduto,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          SizedBox(
            child: ActionButton.instantiate(
              viewModel:ButtonViewModel(
                size: ActionButtonSize.medium, 
                style:  ActionButtonStyle.primary, 
                text: 'Vizualizar produto', 
                onPressed: (){
                  Navigator.push(
                    context, 
                    MaterialPageRoute(builder: (context) => const ProdutoScreen()),
                  );
                }
              ) 
            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context){
    return createCard(context);
  }
  
}