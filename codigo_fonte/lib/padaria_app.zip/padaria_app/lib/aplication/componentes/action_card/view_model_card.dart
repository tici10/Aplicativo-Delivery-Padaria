import 'package:flutter/material.dart';

class CardViewModel{
  final String image;
  final String nome;
  final String preco;

  CardViewModel({
    required this.image,
    required this.nome,
    required this.preco,
  });

}