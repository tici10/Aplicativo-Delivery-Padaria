import 'package:flutter/material.dart';

class LoadViewModel {
  final Image image;
  final String text;

  LoadViewModel({
    required this.image,
    required this.text,
  });
}