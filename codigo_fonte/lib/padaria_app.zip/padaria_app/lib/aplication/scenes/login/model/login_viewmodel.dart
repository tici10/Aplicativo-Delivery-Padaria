import 'package:flutter/material.dart';

class Loginmodel {
  final String nome;
  final String email;

  Loginmodel({
    required this.nome,
    required this.email,
  });
}