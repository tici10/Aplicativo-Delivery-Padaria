import 'package:flutter/material.dart';

const Color primaryBaseColor = Color(0x3C2605);
const Color secondaryBaseColor = Color(0xAE8549);
const Color tertiaryBaseColor = Color(0xD2CCC5);

