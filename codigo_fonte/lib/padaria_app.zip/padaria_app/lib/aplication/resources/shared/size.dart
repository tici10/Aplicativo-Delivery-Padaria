import 'package:flutter/material.dart';

const int smallBase = 16;

const int mediumBase = 24;

const int largeBase = 30;